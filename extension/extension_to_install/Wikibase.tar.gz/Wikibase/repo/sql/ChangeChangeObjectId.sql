ALTER TABLE /*_*/wb_changes MODIFY change_object_id varbinary(14) NOT NULL;
