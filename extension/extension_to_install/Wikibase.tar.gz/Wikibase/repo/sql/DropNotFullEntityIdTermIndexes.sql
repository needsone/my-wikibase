DROP INDEX /*i*/term_search ON /*_*/wb_terms;
DROP INDEX /*i*/term_entity ON /*_*/wb_terms;