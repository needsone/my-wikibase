var ModuleLoader = require( './moduleLoader' );

module.exports = new ModuleLoader();
