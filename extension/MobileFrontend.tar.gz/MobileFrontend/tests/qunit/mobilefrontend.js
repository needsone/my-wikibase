/* global QUnit */
QUnit.module( 'MobileFrontend' );
QUnit.skip( 'Tests are not loaded - please run `npm run build` in extension directory' );
