/**
 * A list of all custom Minerva pageObjects.
 * To simplify imports in world.js.
 */
module.exports = {
	ArticlePage: require( './article_page' )
};
